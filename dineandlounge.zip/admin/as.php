<?php
    $hashedPassword = password_hash("asd", PASSWORD_DEFAULT);
    echo $hashedPassword; // to see the hashed output
?>
